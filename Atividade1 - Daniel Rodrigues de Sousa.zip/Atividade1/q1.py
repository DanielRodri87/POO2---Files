temp = int(input("Informe a temperatura em graus Farenhait: "))
temp_celsius = (5 * (temp-32) / 9)
print(f"A temperatura em graus Celsius é: {temp_celsius:.2f}")