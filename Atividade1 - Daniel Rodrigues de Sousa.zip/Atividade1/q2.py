
peso = int(input("Informe o peso do peixe: "))
if peso > 50:
    valor_multa = (peso-50)*4
    
print(f"O valor da multa é: {valor_multa} reais")