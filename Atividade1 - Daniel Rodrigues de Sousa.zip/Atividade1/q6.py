# Faça um programa que peça dois números, base e expoente, calcule e mostre o primeiro
# número elevado ao segundo número. Não utilize a função de potência da linguagem.

base = float(input("Base: "))
expoente = float(input("Expoente: "))

print(base**expoente)